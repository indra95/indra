class Pricepoint < ActiveRecord::Base
end
