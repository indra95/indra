class Dataset < ActiveRecord::Base
end
